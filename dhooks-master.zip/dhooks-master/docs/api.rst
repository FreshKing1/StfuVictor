.. currentmodule:: dhooks

API Reference
=============

The following section outlines the API of dhooks.


Webhook
-------

.. autoclass:: dhooks.Webhook
    :members:

File
----
.. autoclass:: dhooks.File
    :members:

Embed
-----
.. autoclass:: dhooks.Embed
    :members:

